#!/bin/sh
#
# Script to launch 4 windows and start testing
#
xterm -e perl StressTester.pl &
xterm -e perl StressTester.pl &
xterm -e perl StressTester.pl &
xterm -e perl StressTester.pl &
