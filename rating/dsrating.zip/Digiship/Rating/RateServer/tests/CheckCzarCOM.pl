#
# Check the Czar COM installation
#
$CzarPath = "C:\\czar";
$CzarDLL = $CzarPath . "\\" . "czar32.dll";
$CzarMaint = $CzarPath . "\\" . "mainten.exe";

$SystemPath = "c:\\windows\\system";

$DigishipRateDll = $SystemPath . "\\" . "DigishipRate.dll";
$RateConfig = "c:\\RateConfig.txt";


# Check to make sure the CzarDLL is in place

# Check to make sure the maint program is in place

# Check to make sure the DigishipRate dll is in place

# Check to make sure the RateConfig.txt file is in place
